# Source

Main Windows project:

```text
PhonePadBridge.WebBridge
```

Build one EXE:

```bat
cd PhonePadBridge.WebBridge
build_single_exe.bat
```
